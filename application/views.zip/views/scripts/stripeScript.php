<!-- Stripe JavaScript library -->
<script src="https://js.stripe.com/v3/"></script>
<script>
    // Create an instance of the Stripe object
    // Set your publishable API key
    var stripe = Stripe('pk_test_51SPt1WHz56QdCFhGsjKLXIZ3aHN9dKdbcYCBJCH18HTppZRjW9Ieh3tUKdgBbUEdQ5S4EFQ6tLEsYeiZReFxcl1800gJRGbrrx');

    // Create an instance of elements
    var elements = stripe.elements();
    var er_msg = document.getElementById('card_invalid_message');
    var style = {
        base: {
            fontWeight: 400,
            fontFamily: 'Roboto, Open Sans, Segoe UI, sans-serif',
            fontSize: '16px',
            lineHeight: '1.4',
            color: '#555',
            backgroundColor: '#fff',
            '::placeholder': {
                color: '#888',
            },
        },
        invalid: {
            color: '#eb1c26',
        }
    };

    var cardElement = elements.create('cardNumber', {
        style: style
    });
    cardElement.mount('#card_number');

    var exp = elements.create('cardExpiry', {
        'style': style
    });
    exp.mount('#card_expiry');

    var cvc = elements.create('cardCvc', {
        'style': style
    });
    cvc.mount('#card_cvc');

    // Validate input of the card elements
    var resultContainer = document.getElementById('card_invalid_message');
    var resultExp = document.getElementById('card_exp_message');
    cardElement.addEventListener('change', function(event) {
        if (event.error) {
            //alert("error");
            resultContainer.innerHTML = 'Card Number Is Invalid';
        } else {
            resultContainer.innerHTML = '';
        }
    });

    exp.addEventListener('change', function(event) {
        if (event.error) {
            //alert("error");
            resultExp.innerHTML = 'Expiry Date Is Not Valid';
        } else {
            resultExp.innerHTML = '';
        }
    });
    // Get payment form element
    // var form = document.getElementById('form-4');

    // // Create a token when the form is submitted.
    // form.addEventListener('submit', function(e) {
    //     e.preventDefault();
    //     createToken();
    // });

    // // Create single-use token to charge the user
    // function createToken() {
    //     stripe.createToken(cardElement).then(function(result) {
    //         if (result.error) {
    //             // Inform the user if there was an error
    //             resultContainer.innerHTML = '<p>' + result.error.message + '</p>';
    //         } else {
    //             // Send the token to your server
    //             stripeTokenHandler(result.token);
    //         }
    //     });
    // }

    // // Callback to handle the response from stripe
    // function stripeTokenHandler(token) {
    //     // Insert the token ID into the form so it gets submitted to the server
    //     var hiddenInput = document.createElement('input');
    //     hiddenInput.setAttribute('type', 'hidden');
    //     hiddenInput.setAttribute('name', 'stripeToken');
    //     hiddenInput.setAttribute('value', token.id);
    //     form.appendChild(hiddenInput);

        // Submit the form
        // form.submit(function(e) {
        //     e.preventDefault();
        //     //alert("hi");

        //     $.ajax({
        //         url: '<?php echo site_url('Jobmanagement/purchase'); ?>',
        //         type: "post",
        //         data: new FormData(this),
        //         processData: false,
        //         contentType: false,
        //         cache: false,
        //         async: false,
        //         /*beforeSend: function(){
        //         $('#submit_button_apply').text('Wait...');
        //     },*/
        //         success: function(data) {
        //             //alert("Job Posted Successfully");
        //             //window.location="<?php //echo site_url('Jobmanagement/pricingplans')
        //                                 ?>";

        //         }
        //     });

        // });
    //}
</script>