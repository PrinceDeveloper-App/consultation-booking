<ul class="list-inline dashboard-menu text-center">
    <li><a class="<?php if(isset($pageid) && $pageid == "dash"){?>active<?php } ?>" href="<?php echo base_url("Administrator/Dashboard") ?>">Dashboard</a></li>
    <li><a class="<?php if(isset($pageid) && $pageid == "schedule"){?>active<?php } ?>" href="<?php echo base_url("Administrator/Schedule/create") ?>">Scheduling</a></li>
    <li><a href="address.html">Address</a></li>
    <li><a href="profile-details.html">Profile Details</a></li>
</ul>