<footer class="footer section text-center" style="padding-top: 0px !important;padding-bottom: 80px;">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<!-- <ul class="social-media">
					<li>
						<a href="https://www.facebook.com/themefisher">
							<i class="tf-ion-social-facebook"></i>
						</a>
					</li>
					<li>
						<a href="https://www.instagram.com/themefisher">
							<i class="tf-ion-social-instagram"></i>
						</a>
					</li>
					<li>
						<a href="https://www.twitter.com/themefisher">
							<i class="tf-ion-social-twitter"></i>
						</a>
					</li>
					<li>
						<a href="https://www.pinterest.com/themefisher/">
							<i class="tf-ion-social-pinterest"></i>
						</a>
					</li>
				</ul> -->
				<ul class="footer-menu text-uppercase">
					<li>
						<a href="<?php echo base_url() ?>Aboutus">About Us</a>
					</li>

					<li>
						<a href="#">Book Consultation</a>
					</li>

					<li>
						<a href="#">PRIVACY POLICY</a>
					</li>
					<li>
						<a href="<?php echo base_url() ?>Contactus">CONTACT</a>
					</li>
				</ul>
				<p class="copyright-text" style="text-align: center;text-align-last: center;">
					Copyright &copy;&nbsp;<?php echo date("Y"); ?>, Designed &amp; Developed by 
					<a href="https://acode.ca/">Acode</a>
				</p>
			</div>
		</div>
	</div>
</footer>