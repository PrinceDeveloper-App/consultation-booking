<!-- Start Top Header Bar -->
<section class="top-header">
	<div class="container">
		<div class="row">
			<div class="col-md-4 col-xs-12 col-sm-4">
				<div class="contact-number">
					<i class="tf-ion-ios-telephone"></i>
					<span>+1 7806556599</span>&nbsp;
					<i class="tf-ion-ios-email"></i>
					<span>info@ikic.ca</span>
				</div>
			</div>
			<style>
				.top-logo {
					display: flex;
					justify-content: center;
					/* centers horizontally */
					align-items: center;
					/* centers vertically */
					height: auto;
					/* example: full viewport height */
					width: 100%;
					/* full width */
					background-color: #fff;
					/* optional */
				}

				.image-logo {
					width: 120px;
					/* your desired width */
					height: 36px;
					/* your desired height */
					object-fit: contain;
					/* keeps aspect ratio and avoids distortion */
					image-rendering: -webkit-optimize-contrast;
					/* keeps edges crisp */
				}
			</style>
			<div class="col-md-4 col-xs-12 col-sm-4">
				<!-- Site Logo -->
				<div class="logo text-center top-logo">
					<a href="<?php echo base_url() ?>">
						<!-- replace logo here -->
						<img class="img-responsive image-logo" src="<?php echo base_url() ?>resources/images/logo-ikic-02.jpg">
						<!-- <svg width="135px" height="29px" viewBox="0 0 155 29" version="1.1" xmlns="http://www.w3.org/2000/svg"
							xmlns:xlink="http://www.w3.org/1999/xlink">
							<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" font-size="40"
								font-family="AustinBold, Austin" font-weight="bold">
								<g id="Group" transform="translate(-108.000000, -297.000000)" fill="#000000">
									<text id="AVIATO">
										<tspan x="108.94" y="325">IKIC</tspan>
									</text>
								</g>
							</g>
						</svg> -->
					</a>
				</div>
			</div>
			<div class="col-md-4 col-xs-12 col-sm-4">
				<!-- Cart -->
				<ul class="text-center list-inline">
					<li class="dropdown cart-nav dropdown-slide">
						<a href="<?php echo base_url() ?>book-consultation/select-booking-type" class="btn btn-main btn-small" style="font-size: 14px;">Book Consultation</a>

					</li><!-- / Cart -->



				</ul><!-- / .nav .navbar-nav .navbar-right -->
			</div>
		</div>
	</div>
</section><!-- End Top Header Bar -->